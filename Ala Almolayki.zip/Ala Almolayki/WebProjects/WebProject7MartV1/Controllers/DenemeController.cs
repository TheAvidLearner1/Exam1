﻿using Microsoft.AspNetCore.Mvc;

namespace WebProject7MartV1.Controllers
{
    public class DenemeController : Controller
    {
        public IActionResult Okulumuz()
        {
            return View();
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;

namespace WebProje28SubatV2.Controllers
{
    public class DuyuruController : Controller
    {
        public IActionResult Duyurularimiz()
        {
            return View();
        }
    }
}

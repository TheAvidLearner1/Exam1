﻿using Microsoft.AspNetCore.Mvc;

namespace WebProje28SubatV2.Controllers
{
    public class OkulController : Controller
    {
        public IActionResult Projelerimiz()
        {
            return View();
        }
    }
}
